﻿using System.Windows.Controls;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public static class Init
    {
        public static Pen Pen = new Pen(Brushes.Black, 2);
        public static Brush Brush = Brushes.Transparent;

        public static Image? DrawingImage;

        public static double CanvasWidth = 800;
        public static double CanvasHeight = 500;
    }
}