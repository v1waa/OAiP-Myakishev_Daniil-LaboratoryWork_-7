﻿using DrawFigureLibrary;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Laba7OAiP
{
    public partial class MainWindow : Window
    {
        private RenderTargetBitmap? renderTarget;
        private Figure? selectedFigure;
        private bool isDragging = false;
        private Point lastMousePoint;

        public MainWindow()
        {
            InitializeComponent();

            Loaded += MainWindow_Loaded;
            SizeChanged += MainWindow_SizeChanged;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Init.DrawingImage = DrawingImage;

            CreateCanvas();
            UpdateMenu();
        }

        private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (IsLoaded)
            {
                CreateCanvas();
            }
        }

        private void CreateCanvas()
        {
            int width = (int)drawingBorder.ActualWidth;
            int height = (int)drawingBorder.ActualHeight;

            if (width <= 0)
            {
                width = 760;
            }

            if (height <= 0)
            {
                height = 600;
            }

            Init.CanvasWidth = width;
            Init.CanvasHeight = height;

            renderTarget = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            DrawingImage.Source = renderTarget;

            Redraw();
        }

        private void AddShape_Click(object sender, RoutedEventArgs e)
        {
            Figure? figure = CreateFigure();

            if (figure == null)
            {
                return;
            }

            try
            {
                figure.MoveTo(0, 0, Init.CanvasWidth, Init.CanvasHeight);

                ShapeContainer.Add(figure);
                selectedFigure = figure;

                RefreshList();
                lstShapes.SelectedIndex = ShapeContainer.Figures.Count - 1;

                Redraw();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ChangeSelectedShape_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFigure == null)
            {
                MessageBox.Show("Выберите фигуру.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!ReadNumber(txtX.Text, "X", out double newX))
            {
                return;
            }

            if (!ReadNumber(txtY.Text, "Y", out double newY))
            {
                return;
            }

            double oldX = selectedFigure.X;
            double oldY = selectedFigure.Y;
            double oldW = selectedFigure.W;
            double oldH = selectedFigure.H;

            try
            {
                selectedFigure.MoveTo(newX - selectedFigure.X, newY - selectedFigure.Y, Init.CanvasWidth, Init.CanvasHeight);

                if (!ChangeSize())
                {
                    selectedFigure.X = oldX;
                    selectedFigure.Y = oldY;
                    selectedFigure.W = oldW;
                    selectedFigure.H = oldH;
                    Redraw();
                    return;
                }

                RefreshList();
                SelectFigureInList(selectedFigure);
                FillFields();
                Redraw();
            }
            catch (Exception ex)
            {
                selectedFigure.X = oldX;
                selectedFigure.Y = oldY;
                selectedFigure.W = oldW;
                selectedFigure.H = oldH;

                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);

                FillFields();
                Redraw();
            }
        }

        private bool ChangeSize()
        {
            switch (selectedFigure)
            {
                case CircleShape circle:
                    if (!ReadNumber(txtW.Text, "Радиус", out double radius))
                    {
                        return false;
                    }

                    circle.ChangeRadius(radius, Init.CanvasWidth, Init.CanvasHeight);
                    return true;

                case SquareShape square:
                    if (!ReadNumber(txtW.Text, "Сторона", out double side))
                    {
                        return false;
                    }

                    square.ResizeSide(side, Init.CanvasWidth, Init.CanvasHeight);
                    return true;

                case RectangleShape rectangle:
                    if (!ReadNumber(txtW.Text, "Ширина", out double rectW))
                    {
                        return false;
                    }

                    if (!ReadNumber(txtH.Text, "Высота", out double rectH))
                    {
                        return false;
                    }

                    rectangle.Resize(rectW, rectH, Init.CanvasWidth, Init.CanvasHeight);
                    return true;

                case EllipseShape ellipse:
                    if (!ReadNumber(txtW.Text, "Ширина", out double ellipseW))
                    {
                        return false;
                    }

                    if (!ReadNumber(txtH.Text, "Высота", out double ellipseH))
                    {
                        return false;
                    }

                    ellipse.Resize(ellipseW, ellipseH, Init.CanvasWidth, Init.CanvasHeight);
                    return true;

                case ChairShape chair:
                    if (!ReadNumber(txtW.Text, "Ширина стула", out double chairW))
                    {
                        return false;
                    }

                    if (!ReadNumber(txtH.Text, "Высота стула", out double chairH))
                    {
                        return false;
                    }

                    chair.Resize(chairW, chairH, Init.CanvasWidth, Init.CanvasHeight);
                    return true;

                case TriangleShape:
                case PolygonShape:
                    return true;

                default:
                    return true;
            }
        }

        private void DeleteShape_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFigure == null)
            {
                MessageBox.Show("Выберите фигуру.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ShapeContainer.Remove(selectedFigure);

            selectedFigure = null;
            isDragging = false;

            RefreshList();
            Redraw();
        }

        private void ClearCanvas_Click(object sender, RoutedEventArgs e)
        {
            ShapeContainer.Clear();

            selectedFigure = null;
            isDragging = false;

            RefreshList();
            Redraw();
        }

        private void DrawingArea_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point point = e.GetPosition(drawingBorder);

            selectedFigure = null;
            lstShapes.SelectedIndex = -1;

            for (int i = ShapeContainer.Figures.Count - 1; i >= 0; i--)
            {
                Figure figure = ShapeContainer.Figures[i];

                if (figure.ContainsPoint(point))
                {
                    selectedFigure = figure;
                    lstShapes.SelectedIndex = i;

                    lastMousePoint = point;
                    isDragging = true;

                    drawingBorder.CaptureMouse();
                    break;
                }
            }
        }

        private void DrawingArea_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isDragging || selectedFigure == null)
            {
                return;
            }

            Point point = e.GetPosition(drawingBorder);

            double dx = point.X - lastMousePoint.X;
            double dy = point.Y - lastMousePoint.Y;

            try
            {
                selectedFigure.MoveTo(dx, dy, Init.CanvasWidth, Init.CanvasHeight);

                lastMousePoint = point;

                FillFields();
                Redraw();
            }
            catch
            {
                lastMousePoint = point;
            }
        }

        private void DrawingArea_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            drawingBorder.ReleaseMouseCapture();
        }

        private void LstShapes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = lstShapes.SelectedIndex;

            if (index < 0 || index >= ShapeContainer.Figures.Count)
            {
                return;
            }

            selectedFigure = ShapeContainer.Figures[index];

            SelectComboItem(GetFigureName(selectedFigure));
            FillFields();
            UpdateMenu();
        }

        private void CmbShapeType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded)
            {
                UpdateMenu();
            }
        }

        private Figure? CreateFigure()
        {
            string type = GetSelectedType();

            if (!ReadNumber(txtX.Text, "X", out double x))
            {
                return null;
            }

            if (!ReadNumber(txtY.Text, "Y", out double y))
            {
                return null;
            }

            switch (type)
            {
                case "Треугольник":
                    return CreateTriangle(x, y);

                case "Многоугольник":
                    return CreatePolygon(x, y);
            }

            if (!ReadNumber(txtW.Text, lblW.Text.TrimEnd(':'), out double w))
            {
                return null;
            }

            double h = w;

            if (NeedHeight(type))
            {
                if (!ReadNumber(txtH.Text, lblH.Text.TrimEnd(':'), out h))
                {
                    return null;
                }
            }

            switch (type)
            {
                case "Эллипс":
                    return new EllipseShape(x, y, w, h);

                case "Окружность":
                    return new CircleShape(x, y, w);

                case "Прямоугольник":
                    return new RectangleShape(x, y, w, h);

                case "Квадрат":
                    return new SquareShape(x, y, w);

                case "Стул":
                    return new ChairShape(x, y, w, h);

                default:
                    MessageBox.Show("Неизвестный тип фигуры.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return null;
            }
        }

        private TriangleShape? CreateTriangle(double x, double y)
        {
            List<Point> points = ReadPoints();

            if (points.Count != 3)
            {
                MessageBox.Show("Для треугольника нужно 3 вершины.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            return new TriangleShape(x, y, points[0], points[1], points[2]);
        }

        private PolygonShape? CreatePolygon(double x, double y)
        {
            if (!int.TryParse(txtVertexCount.Text, out int count) || count < 3)
            {
                MessageBox.Show("Количество вершин должно быть не меньше 3.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            List<Point> points = ReadPoints();

            if (points.Count != count)
            {
                MessageBox.Show("Количество введённых вершин не совпадает с указанным.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            return new PolygonShape(x, y, points);
        }

        private List<Point> ReadPoints()
        {
            List<Point> points = new List<Point>();

            string[] lines = txtPoints.Text.Split(
                new[] { '\r', '\n' },
                StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                string[] parts = line.Split(
                    new[] { ' ', '\t', ';' },
                    StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length != 2)
                {
                    MessageBox.Show("Ошибка в строке: " + line, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return new List<Point>();
                }

                if (!ReadNumber(parts[0], "X вершины", out double x))
                {
                    return new List<Point>();
                }

                if (!ReadNumber(parts[1], "Y вершины", out double y))
                {
                    return new List<Point>();
                }

                points.Add(new Point(x, y));
            }

            return points;
        }

        private bool ReadNumber(string text, string name, out double value)
        {
            if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out value))
            {
                return true;
            }

            if (double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out value))
            {
                return true;
            }

            MessageBox.Show("Некорректное число в поле \"" + name + "\".", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private void Redraw()
        {
            if (renderTarget == null)
            {
                return;
            }

            DrawingVisual visual = new DrawingVisual();

            using (DrawingContext dc = visual.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, Init.CanvasWidth, Init.CanvasHeight));

                foreach (Figure figure in ShapeContainer.Figures)
                {
                    figure.Draw(dc);
                }
            }

            renderTarget = new RenderTargetBitmap(
                (int)Init.CanvasWidth,
                (int)Init.CanvasHeight,
                96,
                96,
                PixelFormats.Pbgra32);

            renderTarget.Render(visual);
            DrawingImage.Source = renderTarget;
        }

        private void RefreshList()
        {
            lstShapes.Items.Clear();

            for (int i = 0; i < ShapeContainer.Figures.Count; i++)
            {
                lstShapes.Items.Add((i + 1) + ". " + GetFigureName(ShapeContainer.Figures[i]));
            }
        }

        private void FillFields()
        {
            if (selectedFigure == null)
            {
                return;
            }

            txtX.Text = selectedFigure.X.ToString(CultureInfo.InvariantCulture);
            txtY.Text = selectedFigure.Y.ToString(CultureInfo.InvariantCulture);

            switch (selectedFigure)
            {
                case CircleShape circle:
                    txtW.Text = circle.Radius.ToString(CultureInfo.InvariantCulture);
                    txtH.Text = "";
                    break;

                case SquareShape square:
                    txtW.Text = square.W.ToString(CultureInfo.InvariantCulture);
                    txtH.Text = "";
                    break;

                case RectangleShape rectangle:
                    txtW.Text = rectangle.W.ToString(CultureInfo.InvariantCulture);
                    txtH.Text = rectangle.H.ToString(CultureInfo.InvariantCulture);
                    break;

                case EllipseShape ellipse:
                    txtW.Text = ellipse.W.ToString(CultureInfo.InvariantCulture);
                    txtH.Text = ellipse.H.ToString(CultureInfo.InvariantCulture);
                    break;

                case ChairShape chair:
                    txtW.Text = chair.W.ToString(CultureInfo.InvariantCulture);
                    txtH.Text = chair.H.ToString(CultureInfo.InvariantCulture);
                    break;

                case TriangleShape triangle:
                    txtVertexCount.Text = "3";
                    txtPoints.Text = PointsToText(triangle.Points);
                    break;

                case PolygonShape polygon:
                    txtVertexCount.Text = polygon.Points.Count.ToString();
                    txtPoints.Text = PointsToText(polygon.Points);
                    break;
            }
        }

        private string PointsToText(List<Point> points)
        {
            string text = "";

            foreach (Point point in points)
            {
                text += point.X.ToString(CultureInfo.InvariantCulture);
                text += " ";
                text += point.Y.ToString(CultureInfo.InvariantCulture);
                text += Environment.NewLine;
            }

            return text.TrimEnd();
        }

        private void UpdateMenu()
        {
            string type = GetSelectedType();

            bool isPolygon = type == "Треугольник" || type == "Многоугольник";
            bool needHeight = NeedHeight(type);

            lblW.Visibility = isPolygon ? Visibility.Collapsed : Visibility.Visible;
            txtW.Visibility = isPolygon ? Visibility.Collapsed : Visibility.Visible;

            lblH.Visibility = needHeight ? Visibility.Visible : Visibility.Collapsed;
            txtH.Visibility = needHeight ? Visibility.Visible : Visibility.Collapsed;

            lblVertexCount.Visibility = isPolygon ? Visibility.Visible : Visibility.Collapsed;
            txtVertexCount.Visibility = isPolygon ? Visibility.Visible : Visibility.Collapsed;

            lblPoints.Visibility = isPolygon ? Visibility.Visible : Visibility.Collapsed;
            txtPoints.Visibility = isPolygon ? Visibility.Visible : Visibility.Collapsed;

            txtVertexCount.IsEnabled = type != "Треугольник";

            switch (type)
            {
                case "Окружность":
                    lblW.Text = "Радиус:";
                    break;

                case "Квадрат":
                    lblW.Text = "Сторона:";
                    break;

                case "Эллипс":
                    lblW.Text = "Ширина эллипса:";
                    lblH.Text = "Высота эллипса:";
                    break;

                case "Стул":
                    lblW.Text = "Ширина стула:";
                    lblH.Text = "Высота стула:";
                    break;

                default:
                    lblW.Text = "Ширина:";
                    lblH.Text = "Высота:";
                    break;
            }

            if (type == "Треугольник")
            {
                txtVertexCount.Text = "3";
            }
        }

        private bool NeedHeight(string type)
        {
            return type == "Эллипс" ||
                   type == "Прямоугольник" ||
                   type == "Стул";
        }

        private string GetSelectedType()
        {
            ComboBoxItem item = (ComboBoxItem)cmbShapeType.SelectedItem;
            return item.Content.ToString() ?? "";
        }

        private string GetFigureName(Figure figure)
        {
            switch (figure)
            {
                case CircleShape:
                    return "Окружность";

                case SquareShape:
                    return "Квадрат";

                case EllipseShape:
                    return "Эллипс";

                case RectangleShape:
                    return "Прямоугольник";

                case TriangleShape:
                    return "Треугольник";

                case PolygonShape:
                    return "Многоугольник";

                case ChairShape:
                    return "Стул";

                default:
                    return "Фигура";
            }
        }

        private void SelectComboItem(string text)
        {
            for (int i = 0; i < cmbShapeType.Items.Count; i++)
            {
                ComboBoxItem item = (ComboBoxItem)cmbShapeType.Items[i];

                if (item.Content.ToString() == text)
                {
                    cmbShapeType.SelectedIndex = i;
                    return;
                }
            }
        }

        private void SelectFigureInList(Figure figure)
        {
            int index = ShapeContainer.Figures.IndexOf(figure);

            if (index >= 0)
            {
                lstShapes.SelectedIndex = index;
            }
        }
    }
}