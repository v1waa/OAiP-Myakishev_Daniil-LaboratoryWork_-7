﻿using System;
using System.Windows;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public abstract class Figure
    {
        public double X;
        public double Y;
        public double W;
        public double H;

        protected Figure(double x, double y, double w, double h)
        {
            X = x;
            Y = y;
            W = w;
            H = h;
        }

        public abstract void Draw(DrawingContext dc);

        public virtual void MoveTo(double dx, double dy, double canvasWidth, double canvasHeight)
        {
            double newX = X + dx;
            double newY = Y + dy;

            if (newX < 0 || newY < 0 ||
                newX + W > canvasWidth ||
                newY + H > canvasHeight)
            {
                throw new Exception("Фигура выходит за границы области рисования.");
            }

            X = newX;
            Y = newY;
        }

        public virtual Rect GetBounds()
        {
            return new Rect(X, Y, W, H);
        }

        public virtual bool ContainsPoint(Point point)
        {
            return GetBounds().Contains(point);
        }
    }
}
