﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public class ChairShape : Figure
    {
        private List<Figure> parts = new List<Figure>();

        public ChairShape(double x, double y, double width, double height)
            : base(x, y, width, height)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры стула должны быть положительными.");
            }

            CreateParts();
        }

        public override void Draw(DrawingContext dc)
        {
            foreach (Figure part in parts)
            {
                part.Draw(dc);
            }
        }

        public override void MoveTo(double dx, double dy, double canvasWidth, double canvasHeight)
        {
            double newX = X + dx;
            double newY = Y + dy;

            if (newX < 0 || newY < 0 ||
                newX + W > canvasWidth ||
                newY + H > canvasHeight)
            {
                throw new Exception("Стул выходит за границы области рисования.");
            }

            X = newX;
            Y = newY;

            CreateParts();
        }

        public void Resize(double width, double height, double canvasWidth, double canvasHeight)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры стула должны быть положительными.");
            }

            if (X + width > canvasWidth || Y + height > canvasHeight)
            {
                throw new Exception("Стул выходит за границы области рисования.");
            }

            W = width;
            H = height;

            CreateParts();
        }

        public override bool ContainsPoint(Point point)
        {
            return GetBounds().Contains(point);
        }

        private void CreateParts()
        {
            parts.Clear();

            double t = Math.Max(Math.Min(W, H) * 0.06, 4);

            double seatX = X + W * 0.20;
            double seatY = Y + H * 0.50;
            double seatW = W * 0.60;
            double seatH = t * 2;

            double leftBackX = X + W * 0.18;
            double rightBackX = X + W * 0.82 - t;

            double legY = seatY + seatH;
            double legH = Y + H - legY;

            double leftLegX = seatX + W * 0.08;
            double rightLegX = seatX + seatW - W * 0.08 - t;

            double crossX = leftBackX + t;
            double crossW = rightBackX - crossX;

            parts.Add(new RectangleShape(leftBackX, Y, t, H));
            parts.Add(new RectangleShape(rightBackX, Y, t, H));

            parts.Add(new RectangleShape(seatX, seatY, seatW, seatH));

            parts.Add(new RectangleShape(leftLegX, legY, t, legH));
            parts.Add(new RectangleShape(rightLegX, legY, t, legH));

            parts.Add(new RectangleShape(crossX, Y + H * 0.10, crossW, t));
            parts.Add(new RectangleShape(crossX, Y + H * 0.22, crossW, t));
            parts.Add(new RectangleShape(crossX, Y + H * 0.34, crossW, t));
        }
    }
}