﻿using System.Windows.Media;

namespace DrawFigureLibrary
{
    public class SquareShape : RectangleShape
    {
        public SquareShape(double x, double y, double side)
            : base(x, y, side, side)
        {
        }

        public void ResizeSide(double side, double canvasWidth, double canvasHeight)
        {
            Resize(side, side, canvasWidth, canvasHeight);
        }
    }
}