﻿namespace DrawFigureLibrary
{
    public class CircleShape : EllipseShape
    {
        public CircleShape(double x, double y, double radius)
            : base(x, y, radius * 2, radius * 2)
        {
        }

        public double Radius
        {
            get { return W / 2; }
        }

        public void ChangeRadius(double radius, double canvasWidth, double canvasHeight)
        {
            Resize(radius * 2, radius * 2, canvasWidth, canvasHeight);
        }
    }
}