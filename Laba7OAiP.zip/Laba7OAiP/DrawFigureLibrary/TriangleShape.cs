﻿using System.Collections.Generic;
using System.Windows;

namespace DrawFigureLibrary
{
    public class TriangleShape : PolygonShape
    {
        public TriangleShape(double x, double y, Point p1, Point p2, Point p3)
            : base(x, y, new List<Point> { p1, p2, p3 })
        {
        }
    }
}