﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public class PolygonShape : Figure
    {
        public List<Point> Points = new List<Point>();

        public PolygonShape(double x, double y, List<Point> points)
            : base(x, y, 0, 0)
        {
            if (points.Count < 3)
            {
                throw new Exception("Многоугольник должен иметь минимум 3 вершины.");
            }

            Points = points;
            UpdateSize();
        }

        public override void Draw(DrawingContext dc)
        {
            StreamGeometry geometry = new StreamGeometry();

            using (StreamGeometryContext context = geometry.Open())
            {
                context.BeginFigure(GetAbsolutePoint(Points[0]), true, true);

                for (int i = 1; i < Points.Count; i++)
                {
                    context.LineTo(GetAbsolutePoint(Points[i]), true, false);
                }
            }

            dc.DrawGeometry(Init.Brush, Init.Pen, geometry);
        }

        public override void MoveTo(double dx, double dy, double canvasWidth, double canvasHeight)
        {
            Rect bounds = GetBounds();

            double newLeft = bounds.Left + dx;
            double newTop = bounds.Top + dy;

            if (newLeft < 0 || newTop < 0 ||
                newLeft + bounds.Width > canvasWidth ||
                newTop + bounds.Height > canvasHeight)
            {
                throw new Exception("Фигура выходит за границы области рисования.");
            }

            X += dx;
            Y += dy;
        }

        public override Rect GetBounds()
        {
            double minX = Points[0].X;
            double minY = Points[0].Y;
            double maxX = Points[0].X;
            double maxY = Points[0].Y;

            foreach (Point p in Points)
            {
                if (p.X < minX) minX = p.X;
                if (p.Y < minY) minY = p.Y;
                if (p.X > maxX) maxX = p.X;
                if (p.Y > maxY) maxY = p.Y;
            }

            return new Rect(X + minX, Y + minY, maxX - minX, maxY - minY);
        }

        public override bool ContainsPoint(Point point)
        {
            return GetBounds().Contains(point);
        }

        private Point GetAbsolutePoint(Point point)
        {
            return new Point(X + point.X, Y + point.Y);
        }

        private void UpdateSize()
        {
            Rect bounds = GetBounds();
            W = bounds.Width;
            H = bounds.Height;
        }
    }
}