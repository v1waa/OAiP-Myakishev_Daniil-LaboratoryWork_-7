﻿using System;
using System.Windows;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public class EllipseShape : Figure
    {
        public EllipseShape(double x, double y, double width, double height)
            : base(x, y, width, height)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры эллипса должны быть положительными.");
            }
        }

        public override void Draw(DrawingContext dc)
        {
            Point center = new Point(X + W / 2, Y + H / 2);
            dc.DrawEllipse(Init.Brush, Init.Pen, center, W / 2, H / 2);
        }

        public void Resize(double width, double height, double canvasWidth, double canvasHeight)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры должны быть положительными.");
            }

            if (X + width > canvasWidth || Y + height > canvasHeight)
            {
                throw new Exception("Фигура выходит за границы области рисования.");
            }

            W = width;
            H = height;
        }

        public override bool ContainsPoint(Point point)
        {
            double centerX = X + W / 2;
            double centerY = Y + H / 2;

            double dx = (point.X - centerX) / (W / 2);
            double dy = (point.Y - centerY) / (H / 2);

            return dx * dx + dy * dy <= 1;
        }
    }
}

