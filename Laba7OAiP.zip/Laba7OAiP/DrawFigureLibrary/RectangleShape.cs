﻿using System;
using System.Windows;
using System.Windows.Media;

namespace DrawFigureLibrary
{
    public class RectangleShape : Figure
    {
        public RectangleShape(double x, double y, double width, double height)
            : base(x, y, width, height)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры прямоугольника должны быть положительными.");
            }
        }

        public override void Draw(DrawingContext dc)
        {
            dc.DrawRectangle(Init.Brush, Init.Pen, new Rect(X, Y, W, H));
        }

        public void Resize(double width, double height, double canvasWidth, double canvasHeight)
        {
            if (width <= 0 || height <= 0)
            {
                throw new Exception("Размеры должны быть положительными.");
            }

            if (X + width > canvasWidth || Y + height > canvasHeight)
            {
                throw new Exception("Фигура выходит за границы области рисования.");
            }

            W = width;
            H = height;
        }
    }
}