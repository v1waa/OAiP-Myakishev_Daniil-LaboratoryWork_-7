﻿using System.Collections.Generic;

namespace DrawFigureLibrary
{
    public static class ShapeContainer
    {
        public static List<Figure> Figures = new List<Figure>();

        public static void Add(Figure figure)
        {
            Figures.Add(figure);
        }

        public static void Remove(Figure figure)
        {
            Figures.Remove(figure);
        }

        public static void Clear()
        {
            Figures.Clear();
        }
    }
}